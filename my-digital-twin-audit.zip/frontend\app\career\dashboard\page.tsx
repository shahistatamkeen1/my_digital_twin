"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type Application = {
  id: number;
  company: string;
  role: string;
  location: string;
  status: string;
  date_applied: string;
  notes: string;
};

type CareerMemory = {
  id?: number;
  career_goal: string;
  target_role: string;
  current_skills: string;
  skills_to_learn: string;
  notes: string;
};

type CareerIntelligence = {
  daily_focus: string;
  skill_to_learn: string;
  project_task: string;
  interview_topic: string;
  application_goal: string;
  reason: string;
  priority_level: string;
};

export default function DashboardPage() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [memory, setMemory] = useState<CareerMemory | null>(null);
  const [careerIntelligence, setCareerIntelligence] =
    useState<CareerIntelligence | null>(null);

  const fetchApplications = async () => {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/applications/`);
    const data = await res.json();
    setApplications(data);
  };

  const fetchMemory = async () => {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/memory/`);
    const data = await res.json();
    setMemory(data);
  };

  const fetchCareerIntelligence = async () => {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/api/career-intelligence/`
      );
      const data = await res.json();

      if (!data.error) {
        setCareerIntelligence(data);
      }
    } catch (error) {
      console.error("Could not load career intelligence", error);
    }
  };

  useEffect(() => {
    fetchApplications();
    fetchMemory();
    fetchCareerIntelligence();
  }, []);

  const total = applications.length;
  const saved = applications.filter((app) => app.status === "Saved").length;
  const applied = applications.filter((app) => app.status === "Applied").length;
  const interviews = applications.filter((app) => app.status === "Interview").length;
  const offers = applications.filter((app) => app.status === "Offer").length;
  const rejected = applications.filter((app) => app.status === "Rejected").length;

  const recentApplications = applications.slice(0, 5);

 const memoryCompletion = memory ? 100 : 0;
const applicationActivity = Math.min(total * 20, 100);
const interviewReadiness = interviews > 0 ? 80 : 40;
const offerStrength = offers > 0 ? 100 : 50;

const twinIntelligenceScore = Math.round(
  memoryCompletion * 0.3 +
    applicationActivity * 0.3 +
    interviewReadiness * 0.25 +
    offerStrength * 0.15
);

  const quickActions = [
    {
      title: "Update Memory",
      description: "Update your goals, skills, and preferences.",
      href: "/career/memory",
    },
    {
      title: "Update Roadmap",
      description: "Track your 30-day career growth plan.",
      href: "/career/roadmap",
    },
    {
      title: "Generate Cover Letter",
      description: "Generate a cover letter manually.",
      href: "/career/cover-letter",
    },
    {
      title: "Prepare Interview",
      description: "Practice role-based interview questions.",
      href: "/career/interview-prep",
    },
  ];

  const statusItems = [
    { label: "Saved", value: saved },
    { label: "Applied", value: applied },
    { label: "Interview", value: interviews },
    { label: "Offer", value: offers },
    { label: "Rejected", value: rejected },
  ];

  return (
    <>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold">Career Twin Dashboard</h1>
          <p className="mt-2 text-slate-400">
            Your AI-powered career command center.
          </p>
        </div>

        <Link
          href="/career/applications"
          className="rounded-lg bg-indigo-600 px-4 py-2 font-medium hover:bg-indigo-500"
        >
          Add Application
        </Link>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4 lg:gap-5">
        <div className="bg-slate-900 p-5 rounded-xl">
          <p className="text-slate-400 text-sm">Total Applications</p>
          <h2 className="text-4xl font-bold mt-2">{total}</h2>
        </div>

        <div className="bg-slate-900 p-5 rounded-xl">
          <p className="text-slate-400 text-sm">Applied</p>
          <h2 className="text-4xl font-bold mt-2">{applied}</h2>
        </div>

        <div className="bg-slate-900 p-5 rounded-xl">
          <p className="text-slate-400 text-sm">Interviews</p>
          <h2 className="text-4xl font-bold mt-2 text-yellow-400">
            {interviews}
          </h2>
        </div>

        <div className="bg-slate-900 p-5 rounded-xl">
          <p className="text-slate-400 text-sm">Offers</p>
          <h2 className="text-4xl font-bold mt-2 text-green-400">{offers}</h2>
        </div>
      </div>

          <div className="mt-8 rounded-xl bg-slate-900 p-5 sm:p-6">
  <h2 className="text-xl font-semibold">Twin Intelligence Score</h2>

  <p className="text-slate-400 mt-1">
    Your overall Career Twin strength based on memory, applications,
    interviews, and offer progress.
  </p>

  <p className="mt-5 text-4xl font-bold text-indigo-400 sm:text-5xl">
    {twinIntelligenceScore}%
  </p>

  <div className="mt-4 h-3 bg-slate-800 rounded-full">
    <div
      className="h-3 bg-indigo-500 rounded-full"
      style={{ width: `${twinIntelligenceScore}%` }}
    />
  </div>

  <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
    <div className="bg-slate-800 p-4 rounded-lg">
      <p className="text-slate-400 text-sm">Memory Completion</p>
      <p className="text-2xl font-bold mt-2">{memoryCompletion}%</p>
    </div>

    <div className="bg-slate-800 p-4 rounded-lg">
      <p className="text-slate-400 text-sm">Application Activity</p>
      <p className="text-2xl font-bold mt-2">{applicationActivity}%</p>
    </div>

    <div className="bg-slate-800 p-4 rounded-lg">
      <p className="text-slate-400 text-sm">Interview Readiness</p>
      <p className="text-2xl font-bold mt-2">{interviewReadiness}%</p>
    </div>

    <div className="bg-slate-800 p-4 rounded-lg">
      <p className="text-slate-400 text-sm">Offer Strength</p>
      <p className="text-2xl font-bold mt-2">{offerStrength}%</p>
    </div>
  </div>

  <div className="mt-5 rounded-xl border border-indigo-500/20 bg-indigo-500/10 p-4">
  <p className="text-sm font-semibold text-indigo-300">
    AI Insight of the Day
  </p>

  <p className="mt-2 text-sm leading-6 text-slate-300">
    Your interview readiness is currently lower than your application
    activity.
  </p>

  <p className="mt-3 text-sm font-medium text-white">
    Recommended next step
  </p>

  <p className="mt-1 text-sm leading-6 text-slate-300">
    Generate an interview preparation plan and complete three mock
    questions.
  </p>
</div>
</div>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {quickActions.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="rounded-xl border border-slate-800 bg-slate-900 p-5 transition hover:border-indigo-500/40 hover:bg-slate-800"
          >
            <h2 className="font-semibold">{item.title}</h2>
            <p className="text-slate-400 text-sm mt-2">{item.description}</p>
          </Link>
        ))}
      </div>


      <div className="mt-8 rounded-xl bg-slate-900 p-5 sm:p-6">
        <h2 className="text-xl font-semibold">Application Pipeline</h2>
        <p className="text-slate-400 mt-1">
          Your progress through the hiring pipeline.
        </p>

        <div className="mt-6 space-y-4">
          {statusItems.map((item) => {
            const percent = Math.round((item.value / (total || 1)) * 100);

            return (
              <div key={item.label}>
                <div className="flex items-center justify-between gap-3 text-sm">
                  <span>{item.label}</span>
                 <span className="shrink-0 text-xs text-slate-400 sm:text-sm">
  {item.value} jobs · {percent}%
</span>
                </div>

                <div className="mt-2 h-3 bg-slate-800 rounded-full">
                  <div
                    className="h-3 bg-indigo-500 rounded-full"
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-8 rounded-xl bg-slate-900 p-5 sm:p-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-xl font-semibold">Career Memory</h2>
            <p className="text-slate-400 mt-1">
              What your Digital Twin currently remembers about your goals.
            </p>
          </div>

          <Link
            href="/career/memory"
            className="rounded-lg border border-slate-700 px-4 py-2 text-sm hover:bg-slate-800"
          >
            Edit Memory
          </Link>
        </div>

        {memory ? (
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-2 mt-5">
            <div className="bg-slate-800 p-4 rounded-lg">
              <p className="text-slate-400 text-sm">Career Goal</p>
              <p className="font-medium mt-2 whitespace-pre-wrap">
                {memory.career_goal || "-"}
              </p>
            </div>

            <div className="bg-slate-800 p-4 rounded-lg">
              <p className="text-slate-400 text-sm">Target Role</p>
              <p className="font-medium mt-2">{memory.target_role || "-"}</p>
            </div>

            <div className="bg-slate-800 p-4 rounded-lg">
              <p className="text-slate-400 text-sm">Current Skills</p>
              <p className="font-medium mt-2 whitespace-pre-wrap">
                {memory.current_skills || "-"}
              </p>
            </div>

            <div className="bg-slate-800 p-4 rounded-lg">
              <p className="text-slate-400 text-sm">Skills to Learn</p>
              <p className="font-medium mt-2 whitespace-pre-wrap">
                {memory.skills_to_learn || "-"}
              </p>
            </div>
          </div>
        ) : (
          <div className="mt-5 rounded-lg bg-slate-800 p-4">
            <p className="text-slate-300">No Career Memory saved yet.</p>

            <Link
              href="/career/memory"
              className="inline-block mt-3 text-indigo-400 hover:text-indigo-300"
            >
              Create Career Memory
            </Link>
          </div>
        )}
      </div>

      <div className="mt-8 rounded-xl bg-slate-900 p-5 sm:p-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-xl font-semibold">Career Intelligence</h2>
            <p className="text-slate-400 mt-1">
              Your AI-generated career focus for today.
            </p>
          </div>

          <Link
            href="/career/career-intelligence"
            className="rounded-lg border border-slate-700 px-4 py-2 text-sm hover:bg-slate-800"
          >
            Open Agent
          </Link>
        </div>

        {careerIntelligence ? (
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-3 mt-5">
            <div className="bg-slate-800 p-4 rounded-lg">
              <p className="text-slate-400 text-sm">Daily Focus</p>
              <p className="font-medium mt-2">
                {careerIntelligence.daily_focus}
              </p>
            </div>

            <div className="bg-slate-800 p-4 rounded-lg">
              <p className="text-slate-400 text-sm">Skill to Learn</p>
              <p className="font-medium mt-2">
                {careerIntelligence.skill_to_learn}
              </p>
            </div>

            <div className="bg-slate-800 p-4 rounded-lg">
              <p className="text-slate-400 text-sm">Interview Topic</p>
              <p className="font-medium mt-2">
                {careerIntelligence.interview_topic}
              </p>
            </div>

            <div className="bg-slate-800 p-4 rounded-lg md:col-span-2">
              <p className="text-slate-400 text-sm">Project Task</p>
              <p className="font-medium mt-2">
                {careerIntelligence.project_task}
              </p>
            </div>

            <div className="bg-slate-800 p-4 rounded-lg">
              <p className="text-slate-400 text-sm">Priority</p>
              <p className="font-medium mt-2">
                {careerIntelligence.priority_level}
              </p>
            </div>
          </div>
        ) : (
          <div className="mt-5 bg-slate-800 p-4 rounded-lg">
            <p className="text-slate-300">
              No career intelligence generated yet.
            </p>

            <Link
              href="/career/career-intelligence"
              className="inline-block mt-3 text-indigo-400 hover:text-indigo-300"
            >
              Generate today&apos;s career plan
            </Link>
          </div>
        )}
      </div>

      <div className="mt-8 rounded-xl bg-slate-900 p-5 sm:p-6">
        <h2 className="text-xl font-semibold">Recent Applications</h2>

        {recentApplications.length === 0 ? (
          <p className="text-slate-400 mt-4">
            No applications yet. Add your first application.
          </p>
        ) : (
          <div className="mt-5 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-slate-400 border-b border-slate-700">
                <tr>
                  <th className="text-left py-3">Company</th>
                  <th className="text-left py-3">Role</th>
                  <th className="text-left py-3">Location</th>
                  <th className="text-left py-3">Status</th>
                  <th className="text-left py-3">Date</th>
                </tr>
              </thead>

              <tbody>
                {recentApplications.map((app) => (
                  <tr key={app.id} className="border-b border-slate-800">
                    <td className="py-3">{app.company}</td>
                    <td className="py-3">{app.role}</td>
                    <td className="py-3">{app.location || "-"}</td>
                    <td className="py-3">{app.status}</td>
                    <td className="py-3">{app.date_applied || "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}